Controls:
   Arrow Keys - Move
   Spacebar - "A Button" ( Talk / Accept )
   Shift Key - "B Button" ( Sprint / Decline )
   Z Key - Open menu (overworld)
   X Key - Open status (overworld)